<?php
$config = [
    'title' => '喵次元网盘', // 网站名称
    'describition' => '二次元专属文件分享平台~', // 描述
    'keywords' => '网盘,二次元,文件分享', // 关键词
    'admin' => '1', // 后台开关 1开启 0关闭
    'maxsize' => '10485760', // 最大上传大小 10MB
    'background' => '../static/img/bg.jpg', // 背景图
    'foot' => '© 2025 喵次元网盘 - 萌系文件分享站' // 底部信息
];
?>