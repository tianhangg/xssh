<?php
// 后台管理密匙（建议修改为复杂字符串）
$key = 'NekoPan2025@AdminKey';
?>